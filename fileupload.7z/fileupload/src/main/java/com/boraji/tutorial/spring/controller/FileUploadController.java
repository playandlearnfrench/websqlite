package com.boraji.tutorial.spring.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.boraji.tutorial.spring.service.ApplicationMailer;
import com.boraji.tutorial.spring.service.MailService;

@Controller
public class FileUploadController {

	//@Autowired
	//MailService mailService;

	//@Autowired
	//ApplicationMailer applicationMailer;
	
	@Autowired
    JavaMailSender mailSender;
	
	@GetMapping("/")
	public String fileUploadForm(Model model) {
		return "fileUploadForm";
	}

	// Handling file upload request
	@PostMapping("/fileUpload")
	public ResponseEntity<Object> fileUpload(@RequestParam("file") MultipartFile file) throws IOException {

		// Save file on system
		if (!file.getOriginalFilename().isEmpty()) {
			BufferedOutputStream outputStream = new BufferedOutputStream(
					new FileOutputStream(new File("C:/ibomcha/tempupload", file.getOriginalFilename())));
			outputStream.write(file.getBytes());
			outputStream.flush();
			outputStream.close();

			// Mail it after file upload
			//mailService.sendEmail("ibomg@yahoo.com", "Subject: File uploaded successfully",	"File uploaded successfully");
			SimpleMailMessage email = new SimpleMailMessage();
	        email.setTo("ibomg@yahoo.com");
	        email.setSubject("subject test");
	        email.setText("This is just a test message");
	 
	        try {
	            mailSender.send(email);
	            System.out.println("Message Send...");
	        } catch (MailException ex) {
	            System.err.println(ex.getMessage());
	        }

		} else {
			return new ResponseEntity<>("Invalid file.", HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>("File Uploaded Successfully.", HttpStatus.OK);
	}

}
