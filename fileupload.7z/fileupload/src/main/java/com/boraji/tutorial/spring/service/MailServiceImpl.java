package com.boraji.tutorial.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {

	@Autowired
    JavaMailSender mailSender;
 
	@Override
	public void sendEmail(String recipientAddress, String subject, String message) {
		
		SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(recipientAddress);
        email.setSubject(subject);
        email.setText(message);
 
        try {
            mailSender.send(email);
            System.out.println("Message Send...");
        } catch (MailException ex) {
            System.err.println(ex.getMessage());
        }
		
	}
	 
    @Override
    public void sendEmail(String [] recipientAddress,String []bcc,String [] cc, String subject, String message) {
 
    	// creates a simple e-mail object
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(recipientAddress);
        email.setBcc(bcc);
        email.setCc(cc);
        email.setSubject(subject);
        email.setText(message);
 
        try {
            mailSender.send(email);
            System.out.println("Message Send...");
        } catch (MailException ex) {
            System.err.println(ex.getMessage());
        }
    }

	

}
