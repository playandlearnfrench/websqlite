package com.boraji.tutorial.spring.service;

public interface MailService {
	void sendEmail(String recipientAddress, String subject, String message);
	void sendEmail(String[] recipientAddress, String[] bcc, String[] cc, String subject, String message);
}
