//package com.socgen.ewb.service;
//
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//import java.util.concurrent.atomic.AtomicLong;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.socgen.ewb.model.UserOld;
//
//@Service("userService")
//@Transactional
//public class UserServiceImplOld implements UserServiceOld{
//	
//	private static final AtomicLong counter = new AtomicLong();
//	
//	private static List<UserOld> users;
//	
//	static{
//		users= populateDummyUsers();
//	}
//
//	public List<UserOld> findAllUsers() {
//		return users;
//	}
//	
//	public UserOld findById(long id) {
//		for(UserOld user : users){
//			if(user.getId() == id){
//				return user;
//			}
//		}
//		return null;
//	}
//	
//	public UserOld findByName(String name) {
//		for(UserOld user : users){
//			if(user.getUsername().equalsIgnoreCase(name)){
//				return user;
//			}
//		}
//		return null;
//	}
//	
//	public void saveUser(UserOld user) {
//		user.setId(counter.incrementAndGet());
//		users.add(user);
//	}
//
//	public void updateUser(UserOld user) {
//		int index = users.indexOf(user);
//		users.set(index, user);
//	}
//
//	public void deleteUserById(long id) {
//		
//		for (Iterator<UserOld> iterator = users.iterator(); iterator.hasNext(); ) {
//			UserOld user = iterator.next();
//		    if (user.getId() == id) {
//		        iterator.remove();
//		    }
//		}
//	}
//
//	public boolean isUserExist(UserOld user) {
//		return findByName(user.getUsername())!=null;
//	}
//	
//	public void deleteAllUsers(){
//		users.clear();
//	}
//
//	private static List<UserOld> populateDummyUsers(){
//		List<UserOld> users = new ArrayList<UserOld>();
//		users.add(new UserOld(counter.incrementAndGet(),"Sam", "NY", "sam@abc.com"));
//		users.add(new UserOld(counter.incrementAndGet(),"Tomy", "ALBAMA", "tomy@abc.com"));
//		users.add(new UserOld(counter.incrementAndGet(),"Kelly", "NEBRASKA", "kelly@abc.com"));
//		return users;
//	}
//
//}
