package com.socgen.ewb.service;

import java.util.List;

import com.socgen.ewb.model.UserProfile;


public interface UserProfileService {

	UserProfile findById(int id);

	UserProfile findByType(String type);
	
	List<UserProfile> findAll();
	
}
