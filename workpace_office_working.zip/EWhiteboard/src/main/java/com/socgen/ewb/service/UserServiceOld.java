//package com.socgen.ewb.service;
//
//import java.util.List;
//
//import com.socgen.ewb.model.UserOld;
//
//
//
//public interface UserServiceOld {
//	
//	UserOld findById(long id);
//	
//	UserOld findByName(String name);
//	
//	void saveUser(UserOld user);
//	
//	void updateUser(UserOld user);
//	
//	void deleteUserById(long id);
//
//	List<UserOld> findAllUsers(); 
//	
//	void deleteAllUsers();
//	
//	public boolean isUserExist(UserOld user);
//	
//}
